#!/usr/bin/env python3
"""
=============================================================================
PROJET ACTUARIAT PRICING IARD
=============================================================================

Pipeline complet de tarification assurance MRH :
1. Génération/Chargement des données
2. Préparation et exploration
3. Modélisation GLM (Fréquence + Sévérité)
4. Benchmark Machine Learning
5. Construction du zonier
6. Analyse d'impact

Auteur: Ayoub BENHASSAN
Date: Janvier 2026
=============================================================================
"""

import os
import sys
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')

# Ajouter le dossier src au path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from data_preparation import (
    prepare_data, 
    split_train_test, 
    statistiques_sinistralite
)
from glm_models import (
    GLMFrequence, 
    GLMSeverite, 
    GLMQuasiPoisson,
    calculer_prime_pure,
    comparer_modeles
)
from ml_models import (
    RandomForestModel, 
    XGBoostModel,
    evaluer_modele,
    comparer_modeles_ml
)
from zonier import (
    construire_zonier,
    appliquer_zonier,
    analyse_impact,
    simuler_impact_rentabilite,
    exporter_analyse_impact
)


def print_header(title: str):
    """Affiche un header formaté."""
    print("\n" + "=" * 70)
    print(f" {title}")
    print("=" * 70)


def main():
    """
    Pipeline principal du projet.
    """
    print_header("PROJET ACTUARIAT PRICING IARD")
    print("Pipeline de tarification assurance MRH")
    print("Auteur: Ayoub BENHASSAN")
    
    # Créer les dossiers de sortie
    os.makedirs('outputs', exist_ok=True)
    os.makedirs('data', exist_ok=True)
    
    # =========================================================================
    # ÉTAPE 1 : GÉNÉRATION DES DONNÉES (si nécessaire)
    # =========================================================================
    print_header("ÉTAPE 1 : GÉNÉRATION DES DONNÉES")
    
    if not os.path.exists('data/sinistres_mrh.csv'):
        print("Génération des données simulées...")
        from data.generate_data import main as generate_data
        generate_data()
    else:
        print("✓ Données déjà présentes")
    
    # =========================================================================
    # ÉTAPE 2 : PRÉPARATION DES DONNÉES
    # =========================================================================
    print_header("ÉTAPE 2 : PRÉPARATION DES DONNÉES")
    
    # Charger et préparer les données
    df = prepare_data('data/sinistres_mrh.csv', 'data/exposition_mrh.csv')
    
    # Statistiques globales
    print("\n📊 Statistiques de sinistralité globales:")
    stats_global = statistiques_sinistralite(df)
    print(stats_global.T.to_string())
    
    # Statistiques par zone
    print("\n📊 Statistiques par zone géographique:")
    stats_zone = statistiques_sinistralite(df, group_by=['zone_geo'])
    print(stats_zone.to_string())
    
    # Split train/test
    df_train, df_test = split_train_test(df, test_size=0.2, random_state=42)
    
    # =========================================================================
    # ÉTAPE 3 : MODÉLISATION GLM
    # =========================================================================
    print_header("ÉTAPE 3 : MODÉLISATION GLM")
    
    # Variables explicatives
    features = ['type_logement', 'zone_geo', 'age_groupe', 'surface_groupe', 'etage']
    
    # ----- MODÈLE DE FRÉQUENCE (Poisson) -----
    print("\n" + "-" * 50)
    print("3.1 MODÈLE DE FRÉQUENCE (GLM Poisson)")
    print("-" * 50)
    
    model_freq = GLMFrequence()
    model_freq.fit(df_train, features=features)
    
    # Diagnostic de surdispersion
    diagnostic = model_freq.diagnostic_surdispersion(df_train)
    
    # Si surdispersion, utiliser Quasi-Poisson
    if diagnostic['surdispersion']:
        print("\n→ Utilisation du modèle Quasi-Poisson")
        model_freq_qp = GLMQuasiPoisson()
        model_freq_qp.fit(df_train, features=features)
        relativites_freq = model_freq_qp.get_relativites()
    else:
        relativites_freq = model_freq.get_relativites()
    
    print("\n📊 Relativités de fréquence:")
    print(relativites_freq.to_string())
    
    # Sauvegarder les relativités
    relativites_freq.to_csv('outputs/relativites_frequence.csv')
    print("\n✓ Relativités sauvegardées: outputs/relativites_frequence.csv")
    
    # ----- MODÈLE DE SÉVÉRITÉ (Gamma) -----
    print("\n" + "-" * 50)
    print("3.2 MODÈLE DE SÉVÉRITÉ (GLM Gamma)")
    print("-" * 50)
    
    model_sev = GLMSeverite()
    model_sev.fit(df_train, features=features)
    
    relativites_sev = model_sev.get_relativites()
    print("\n📊 Relativités de sévérité:")
    print(relativites_sev.to_string())
    
    # Sauvegarder
    relativites_sev.to_csv('outputs/relativites_severite.csv')
    print("\n✓ Relativités sauvegardées: outputs/relativites_severite.csv")
    
    # ----- CALCUL DE LA PRIME PURE -----
    print("\n" + "-" * 50)
    print("3.3 CALCUL DE LA PRIME PURE")
    print("-" * 50)
    
    df_test['prime_pure_glm'] = calculer_prime_pure(df_test, model_freq, model_sev)
    
    print(f"Prime pure moyenne observée: {df_test['prime_pure'].mean():.2f}€")
    print(f"Prime pure moyenne prédite (GLM): {df_test['prime_pure_glm'].mean():.2f}€")
    
    # Évaluation
    metrics_glm = evaluer_modele(
        df_test['prime_pure'], 
        df_test['prime_pure_glm'],
        "GLM (Fréquence × Sévérité)"
    )
    
    # =========================================================================
    # ÉTAPE 4 : BENCHMARK MACHINE LEARNING
    # =========================================================================
    print_header("ÉTAPE 4 : BENCHMARK MACHINE LEARNING")
    
    # ----- RANDOM FOREST -----
    print("\n" + "-" * 50)
    print("4.1 RANDOM FOREST")
    print("-" * 50)
    
    rf_model = RandomForestModel(n_estimators=200, max_depth=15)
    rf_model.fit(df_train, features=features, target='prime_pure')
    
    df_test['prime_pure_rf'] = rf_model.predict(df_test)
    metrics_rf = evaluer_modele(
        df_test['prime_pure'],
        df_test['prime_pure_rf'],
        "Random Forest"
    )
    
    print("\n📊 Importance des variables (Random Forest):")
    print(rf_model.get_feature_importance().head(10).to_string(index=False))
    
    # ----- XGBOOST -----
    print("\n" + "-" * 50)
    print("4.2 XGBOOST")
    print("-" * 50)
    
    xgb_model = XGBoostModel(max_depth=6, learning_rate=0.1)
    xgb_model.fit(df_train, features=features, target='prime_pure', verbose=False)
    
    df_test['prime_pure_xgb'] = xgb_model.predict(df_test)
    metrics_xgb = evaluer_modele(
        df_test['prime_pure'],
        df_test['prime_pure_xgb'],
        "XGBoost"
    )
    
    print("\n📊 Importance des variables (XGBoost):")
    print(xgb_model.get_feature_importance().head(10).to_string(index=False))
    
    # ----- COMPARAISON -----
    print("\n" + "-" * 50)
    print("4.3 COMPARAISON DES MODÈLES")
    print("-" * 50)
    
    comparison = pd.DataFrame([metrics_glm, metrics_rf, metrics_xgb])
    comparison = comparison.sort_values('rmse')
    print(comparison.to_string(index=False))
    
    # Sauvegarder
    comparison.to_csv('outputs/comparaison_modeles.csv', index=False)
    print("\n✓ Comparaison sauvegardée: outputs/comparaison_modeles.csv")
    
    # =========================================================================
    # ÉTAPE 5 : CONSTRUCTION DU ZONIER
    # =========================================================================
    print_header("ÉTAPE 5 : CONSTRUCTION DU ZONIER")
    
    # Construire le zonier sur les données complètes
    zonier = construire_zonier(df, n_zones=5)
    
    # Sauvegarder
    zonier.to_csv('outputs/zonier_final.csv', index=False)
    print("\n✓ Zonier sauvegardé: outputs/zonier_final.csv")
    
    # =========================================================================
    # ÉTAPE 6 : ANALYSE D'IMPACT
    # =========================================================================
    print_header("ÉTAPE 6 : ANALYSE D'IMPACT")
    
    # Appliquer le zonier
    df_impact = appliquer_zonier(df.copy(), zonier)
    
    # Simuler une révision tarifaire
    # Prime actuelle = Prime pure observée × coefficient de chargement (1.3)
    df_impact['prime_actuelle'] = df_impact['prime_pure'] * 1.3
    
    # Nouvelle prime = Prime technique × relativité géographique
    prime_technique = df_impact['prime_pure'].mean() * 1.3
    df_impact['prime_nouvelle'] = prime_technique * df_impact['relativite_geo']
    
    # Analyse d'impact
    results, df_detail = analyse_impact(
        df_impact,
        col_prime_actuelle='prime_actuelle',
        col_prime_nouvelle='prime_nouvelle',
        segments=['zone_geo', 'type_logement', 'age_groupe']
    )
    
    # Impact sur la rentabilité
    impact_lr = simuler_impact_rentabilite(df_detail)
    
    # Exporter
    exporter_analyse_impact(results, df_detail, 'outputs/analyse_impact.xlsx')
    
    # =========================================================================
    # RÉSUMÉ FINAL
    # =========================================================================
    print_header("RÉSUMÉ DU PROJET")
    
    print("""
    ✅ ÉTAPES RÉALISÉES:
    
    1. Données générées/chargées
       - 50 000 contrats × 4 années = 200 000 observations
       - Variables: type_logement, zone_geo, age, surface, étage
    
    2. Modélisation GLM
       - GLM Poisson pour la fréquence (avec diagnostic surdispersion)
       - GLM Gamma pour la sévérité
       - Prime Pure = Fréquence × Sévérité
    
    3. Benchmark Machine Learning
       - Random Forest
       - XGBoost
       - Comparaison des performances (RMSE, MAE, R²)
    
    4. Construction du zonier
       - 5 zones tarifaires basées sur la prime pure
       - Relativités lissées (credibility weighting)
    
    5. Analyse d'impact
       - Répartition gagnants/perdants
       - Impact par segment
       - Impact sur le loss ratio
    
    📁 FICHIERS GÉNÉRÉS:
    
    - outputs/relativites_frequence.csv
    - outputs/relativites_severite.csv
    - outputs/comparaison_modeles.csv
    - outputs/zonier_final.csv
    - outputs/analyse_impact.xlsx
    """)
    
    print("=" * 70)
    print(" PROJET TERMINÉ AVEC SUCCÈS")
    print("=" * 70)
    
    return df, model_freq, model_sev, rf_model, xgb_model, zonier


if __name__ == "__main__":
    df, model_freq, model_sev, rf_model, xgb_model, zonier = main()
