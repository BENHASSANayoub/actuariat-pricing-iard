# 🎯 Actuariat Pricing IARD

[![Python](https://img.shields.io/badge/Python-3.9+-blue.svg)](https://python.org)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

**Projet complet d'actuariat pricing IARD** : analyse de sinistralité, modélisation GLM (Poisson & Gamma), Machine Learning (Random Forest & XGBoost), construction d'un zonier tarifaire et analyse d'impact.

## 📋 Table des matières

- [Objectif du projet](#-objectif-du-projet)
- [Structure du projet](#-structure-du-projet)
- [Installation](#-installation)
- [Données](#-données)
- [Pipeline de modélisation](#-pipeline-de-modélisation)
- [Résultats](#-résultats)
- [Auteur](#-auteur)

## 🎯 Objectif du projet

Ce projet simule un **cas réel de tarification en assurance IARD** (Incendie, Accidents et Risques Divers). Il couvre l'ensemble du processus actuariel :

1. **Analyse de sinistralité** : fréquence, sévérité, prime pure par segment
2. **Modélisation GLM** : Poisson (fréquence) et Gamma (sévérité)
3. **Gestion de la surdispersion** : Quasi-Poisson, Binomiale Négative
4. **Machine Learning** : Random Forest et XGBoost comme benchmark
5. **Construction d'un zonier** : tarification géographique
6. **Analyse d'impact** : simulation des variations de primes

## 📁 Structure du projet

```
actuariat-pricing-iard/
│
├── data/
│   ├── sinistres_mrh.csv          # Données de sinistres MRH
│   ├── exposition_mrh.csv         # Données d'exposition
│   └── zones_geo.csv              # Référentiel des zones géographiques
│
├── notebooks/
│   ├── 01_exploration_donnees.ipynb
│   ├── 02_glm_frequence.ipynb
│   ├── 03_glm_severite.ipynb
│   ├── 04_machine_learning.ipynb
│   └── 05_zonier_analyse_impact.ipynb
│
├── src/
│   ├── __init__.py
│   ├── data_preparation.py        # Fonctions de préparation des données
│   ├── glm_models.py              # Modèles GLM (Poisson, Gamma)
│   ├── ml_models.py               # Modèles Machine Learning
│   ├── zonier.py                  # Construction du zonier
│   ├── metrics.py                 # Métriques d'évaluation
│   └── visualization.py           # Graphiques et visualisations
│
├── outputs/
│   ├── relativites_frequence.csv
│   ├── relativites_severite.csv
│   ├── zonier_final.csv
│   └── analyse_impact.xlsx
│
├── docs/
│   └── guide_technique.md
│
├── main.py                        # Script principal
├── requirements.txt
├── LICENSE
└── README.md
```

## 🚀 Installation

### 1. Cloner le repository

```bash
git clone https://github.com/BENHASSANayoub/actuariat-pricing-iard.git
cd actuariat-pricing-iard
```

### 2. Créer un environnement virtuel

```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows
```

### 3. Installer les dépendances

```bash
pip install -r requirements.txt
```

### 4. Lancer le projet

```bash
python main.py
```

## 📊 Données

### Fichier `sinistres_mrh.csv`

| Variable | Description | Type |
|----------|-------------|------|
| `id_contrat` | Identifiant unique du contrat | int |
| `annee` | Année de survenance | int |
| `nb_sinistres` | Nombre de sinistres | int |
| `cout_sinistre` | Coût total des sinistres (€) | float |
| `age_assure` | Âge de l'assuré | int |
| `type_logement` | Appartement / Maison | str |
| `surface_m2` | Surface en m² | int |
| `zone_geo` | Code zone géographique | str |
| `anciennete_batiment` | Ancienneté du bâtiment (années) | int |
| `etage` | RDC / Intermédiaire / Dernier | str |
| `duree_contrat_jours` | Durée du contrat en jours | int |

### Fichier `exposition_mrh.csv`

| Variable | Description |
|----------|-------------|
| `id_contrat` | Identifiant du contrat |
| `exposition` | Exposition en années |

## 🔄 Pipeline de modélisation

### Étape 1 : Préparation des données

```python
from src.data_preparation import prepare_data

data = prepare_data('data/sinistres_mrh.csv', 'data/exposition_mrh.csv')
```

- Calcul de l'exposition
- Discrétisation des variables continues (âge, surface, ancienneté)
- Encodage des variables catégorielles
- Traitement des valeurs manquantes et outliers

### Étape 2 : Modèle de Fréquence (GLM Poisson)

```python
from src.glm_models import GLMFrequence

model_freq = GLMFrequence()
model_freq.fit(X_train, y_train, offset=log_expo)
relativites_freq = model_freq.get_relativites()
```

**Formule** : `ln(E[N]) = ln(Exposition) + β₀ + β₁X₁ + ... + βₚXₚ`

### Étape 3 : Modèle de Sévérité (GLM Gamma)

```python
from src.glm_models import GLMSeverite

model_sev = GLMSeverite()
model_sev.fit(X_sinistres, y_cout)
relativites_sev = model_sev.get_relativites()
```

**Formule** : `ln(E[Coût]) = β₀ + β₁X₁ + ... + βₚXₚ`

### Étape 4 : Calcul de la Prime Pure

```
Prime Pure = Fréquence × Sévérité
```

### Étape 5 : Benchmark Machine Learning

```python
from src.ml_models import RandomForestModel, XGBoostModel

rf_model = RandomForestModel()
xgb_model = XGBoostModel()
```

### Étape 6 : Construction du Zonier

```python
from src.zonier import construire_zonier

zonier = construire_zonier(data, n_zones=5)
```

### Étape 7 : Analyse d'Impact

```python
from src.metrics import analyse_impact

impact = analyse_impact(data, ancien_tarif, nouveau_tarif)
```

## 📈 Résultats

### Relativités de Fréquence (exemple)

| Variable | Modalité | Relativité | Interprétation |
|----------|----------|------------|----------------|
| Type logement | Maison | 1.25 | +25% vs Appartement |
| Zone | Urbain | 1.35 | +35% vs Rural |
| Étage | RDC | 1.20 | +20% vs Intermédiaire |

### Comparaison des modèles

| Modèle | RMSE | MAE | R² |
|--------|------|-----|-----|
| GLM | 245.3 | 189.2 | 0.72 |
| Random Forest | 231.8 | 175.4 | 0.76 |
| XGBoost | 225.1 | 168.9 | 0.78 |

### Zonier tarifaire

| Zone | Département | Relativité | Loss Ratio |
|------|-------------|------------|------------|
| Zone 1 | 75, 92, 93 | 1.45 | 78% |
| Zone 2 | 69, 13, 31 | 1.20 | 72% |
| Zone 3 | 33, 34, 06 | 1.05 | 68% |
| Zone 4 | Autres | 0.90 | 62% |
| Zone 5 | Rural | 0.75 | 55% |

## 📚 Concepts clés

### GLM (Modèles Linéaires Généralisés)

Les GLM sont la technique standard en actuariat car ils permettent de modéliser des variables non-normales (comptage, coûts) avec des contraintes (valeurs positives).

**3 composantes** :
1. **Distribution** : Poisson (fréquence), Gamma (sévérité)
2. **Prédicteur linéaire** : η = β₀ + β₁X₁ + ... + βₚXₚ
3. **Fonction de lien** : log (multiplicatif)

### Surdispersion

Quand `Var(N) > E[N]`, le modèle Poisson sous-estime l'incertitude.

**Solutions** :
- Quasi-Poisson (ajustement des erreurs standards)
- Binomiale Négative (paramètre de dispersion)

### Interprétation des relativités

Un coefficient β = 0.26 → Relativité = e^0.26 = 1.30 → **+30% de risque**

## 👨‍💻 Auteur

**Ayoub BENHASSAN**  
MBA Finance Quantitative - ESLSCA Business School  
[LinkedIn](https://linkedin.com/in/ayoub-benhassan)

## 📄 License

Ce projet est sous licence MIT - voir le fichier [LICENSE](LICENSE) pour plus de détails.

---

⭐ **Si ce projet vous a été utile, n'hésitez pas à lui donner une étoile !**
