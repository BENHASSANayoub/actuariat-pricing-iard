"""
Génération de données simulées réalistes pour l'assurance MRH
=============================================================

Ce script génère des données de sinistralité MRH (Multirisque Habitation)
avec des caractéristiques réalistes pour la modélisation actuarielle.

Auteur: Ayoub BENHASSAN
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os

# Seed pour reproductibilité
np.random.seed(42)

# =============================================================================
# PARAMÈTRES DE SIMULATION
# =============================================================================

N_CONTRATS = 50000  # Nombre de contrats
ANNEES = [2021, 2022, 2023, 2024]  # Années de données

# Fréquence de base (sinistres par an)
FREQUENCE_BASE = 0.08  # 8% de fréquence de base

# Coût moyen de base
COUT_MOYEN_BASE = 1200  # 1200€ de coût moyen

# Relativités réalistes pour la fréquence
RELATIVITES_FREQ = {
    'type_logement': {'Appartement': 1.0, 'Maison': 1.25},
    'zone_geo': {'Rural': 0.75, 'Periurbain': 1.0, 'Urbain': 1.35, 'Paris_IDF': 1.55},
    'etage': {'Intermediaire': 1.0, 'RDC': 1.20, 'Dernier': 1.10},
    'age_groupe': {'18-30': 1.15, '31-45': 1.0, '46-60': 0.95, '61+': 1.05},
    'surface_groupe': {'<50m2': 0.85, '50-100m2': 1.0, '100-150m2': 1.15, '>150m2': 1.30},
    'anciennete_groupe': {'<10ans': 0.90, '10-30ans': 1.0, '>30ans': 1.20}
}

# Relativités réalistes pour la sévérité
RELATIVITES_SEV = {
    'type_logement': {'Appartement': 1.0, 'Maison': 1.40},
    'zone_geo': {'Rural': 0.80, 'Periurbain': 1.0, 'Urbain': 1.25, 'Paris_IDF': 1.50},
    'surface_groupe': {'<50m2': 0.70, '50-100m2': 1.0, '100-150m2': 1.35, '>150m2': 1.80},
    'type_sinistre': {'Degat_eaux': 1.0, 'Vol': 2.5, 'Incendie': 12.0, 'RC': 1.5, 'Bris_glace': 0.4}
}

# Distribution des types de sinistres
DISTRIBUTION_SINISTRES = {
    'Degat_eaux': 0.60,
    'Vol': 0.15,
    'Incendie': 0.05,
    'RC': 0.12,
    'Bris_glace': 0.08
}

# Départements par zone
DEPARTEMENTS = {
    'Paris_IDF': ['75', '92', '93', '94', '91', '78', '95', '77'],
    'Urbain': ['69', '13', '31', '33', '59', '67', '06', '34', '44', '35'],
    'Periurbain': ['38', '45', '37', '49', '72', '76', '14', '62', '57', '54'],
    'Rural': ['03', '15', '19', '23', '36', '43', '48', '58', '71', '89']
}

# =============================================================================
# FONCTIONS DE GÉNÉRATION
# =============================================================================

def generer_contrats(n_contrats):
    """Génère les caractéristiques des contrats."""
    
    contrats = []
    
    for i in range(n_contrats):
        # Type de logement (60% appartements, 40% maisons)
        type_logement = np.random.choice(['Appartement', 'Maison'], p=[0.60, 0.40])
        
        # Zone géographique
        zone_geo = np.random.choice(['Rural', 'Periurbain', 'Urbain', 'Paris_IDF'], 
                                    p=[0.25, 0.30, 0.30, 0.15])
        
        # Département
        departement = np.random.choice(DEPARTEMENTS[zone_geo])
        
        # Âge de l'assuré (distribution réaliste)
        age_assure = int(np.clip(np.random.normal(45, 15), 18, 85))
        
        # Groupe d'âge
        if age_assure < 31:
            age_groupe = '18-30'
        elif age_assure < 46:
            age_groupe = '31-45'
        elif age_assure < 61:
            age_groupe = '46-60'
        else:
            age_groupe = '61+'
        
        # Surface (corrélée au type de logement)
        if type_logement == 'Appartement':
            surface_m2 = int(np.clip(np.random.normal(65, 25), 20, 150))
        else:
            surface_m2 = int(np.clip(np.random.normal(120, 40), 50, 300))
        
        # Groupe de surface
        if surface_m2 < 50:
            surface_groupe = '<50m2'
        elif surface_m2 < 100:
            surface_groupe = '50-100m2'
        elif surface_m2 < 150:
            surface_groupe = '100-150m2'
        else:
            surface_groupe = '>150m2'
        
        # Ancienneté du bâtiment
        anciennete_batiment = int(np.clip(np.random.exponential(30), 1, 100))
        
        # Groupe d'ancienneté
        if anciennete_batiment < 10:
            anciennete_groupe = '<10ans'
        elif anciennete_batiment < 30:
            anciennete_groupe = '10-30ans'
        else:
            anciennete_groupe = '>30ans'
        
        # Étage (pour appartements seulement)
        if type_logement == 'Appartement':
            etage = np.random.choice(['RDC', 'Intermediaire', 'Dernier'], p=[0.15, 0.70, 0.15])
        else:
            etage = 'RDC'  # Maison = RDC par défaut
        
        # Durée du contrat (majorité 365 jours, quelques résiliés)
        if np.random.random() < 0.90:
            duree_contrat_jours = 365
        else:
            duree_contrat_jours = np.random.randint(30, 365)
        
        contrats.append({
            'id_contrat': i + 1,
            'type_logement': type_logement,
            'zone_geo': zone_geo,
            'departement': departement,
            'age_assure': age_assure,
            'age_groupe': age_groupe,
            'surface_m2': surface_m2,
            'surface_groupe': surface_groupe,
            'anciennete_batiment': anciennete_batiment,
            'anciennete_groupe': anciennete_groupe,
            'etage': etage,
            'duree_contrat_jours': duree_contrat_jours
        })
    
    return pd.DataFrame(contrats)


def calculer_frequence_attendue(row):
    """Calcule la fréquence attendue pour un contrat donné."""
    
    freq = FREQUENCE_BASE
    
    # Appliquer les relativités
    freq *= RELATIVITES_FREQ['type_logement'][row['type_logement']]
    freq *= RELATIVITES_FREQ['zone_geo'][row['zone_geo']]
    freq *= RELATIVITES_FREQ['etage'][row['etage']]
    freq *= RELATIVITES_FREQ['age_groupe'][row['age_groupe']]
    freq *= RELATIVITES_FREQ['surface_groupe'][row['surface_groupe']]
    freq *= RELATIVITES_FREQ['anciennete_groupe'][row['anciennete_groupe']]
    
    # Ajuster pour l'exposition
    exposition = row['duree_contrat_jours'] / 365
    freq *= exposition
    
    return freq


def calculer_severite_attendue(type_sinistre, row):
    """Calcule la sévérité attendue pour un sinistre donné."""
    
    sev = COUT_MOYEN_BASE
    
    # Appliquer les relativités
    sev *= RELATIVITES_SEV['type_logement'][row['type_logement']]
    sev *= RELATIVITES_SEV['zone_geo'][row['zone_geo']]
    sev *= RELATIVITES_SEV['surface_groupe'][row['surface_groupe']]
    sev *= RELATIVITES_SEV['type_sinistre'][type_sinistre]
    
    return sev


def generer_sinistres(contrats, annee):
    """Génère les sinistres pour une année donnée."""
    
    sinistres = []
    
    for _, contrat in contrats.iterrows():
        # Calculer la fréquence attendue
        freq_attendue = calculer_frequence_attendue(contrat)
        
        # Générer le nombre de sinistres (loi de Poisson)
        nb_sinistres = np.random.poisson(freq_attendue)
        
        # Pour chaque sinistre
        cout_total = 0
        types_sinistres = []
        
        for _ in range(nb_sinistres):
            # Type de sinistre
            type_sin = np.random.choice(
                list(DISTRIBUTION_SINISTRES.keys()),
                p=list(DISTRIBUTION_SINISTRES.values())
            )
            types_sinistres.append(type_sin)
            
            # Coût du sinistre (loi Gamma)
            sev_attendue = calculer_severite_attendue(type_sin, contrat)
            # Paramètres Gamma : shape=2 (asymétrie modérée), scale = sev/2
            cout = np.random.gamma(shape=2, scale=sev_attendue/2)
            cout = max(50, cout)  # Minimum 50€
            cout_total += cout
        
        sinistres.append({
            'id_contrat': contrat['id_contrat'],
            'annee': annee,
            'nb_sinistres': nb_sinistres,
            'cout_sinistre': round(cout_total, 2),
            'types_sinistres': ';'.join(types_sinistres) if types_sinistres else '',
            'type_logement': contrat['type_logement'],
            'zone_geo': contrat['zone_geo'],
            'departement': contrat['departement'],
            'age_assure': contrat['age_assure'],
            'age_groupe': contrat['age_groupe'],
            'surface_m2': contrat['surface_m2'],
            'surface_groupe': contrat['surface_groupe'],
            'anciennete_batiment': contrat['anciennete_batiment'],
            'anciennete_groupe': contrat['anciennete_groupe'],
            'etage': contrat['etage'],
            'duree_contrat_jours': contrat['duree_contrat_jours']
        })
    
    return pd.DataFrame(sinistres)


def generer_zones_geo():
    """Génère le référentiel des zones géographiques."""
    
    zones = []
    for zone, deps in DEPARTEMENTS.items():
        for dep in deps:
            zones.append({
                'departement': dep,
                'zone_geo': zone,
                'libelle_zone': zone.replace('_', ' ')
            })
    
    return pd.DataFrame(zones)


# =============================================================================
# GÉNÉRATION DES DONNÉES
# =============================================================================

def main():
    """Fonction principale de génération des données."""
    
    print("=" * 60)
    print("GÉNÉRATION DES DONNÉES DE SINISTRALITÉ MRH")
    print("=" * 60)
    
    # Créer le dossier data si nécessaire
    os.makedirs('data', exist_ok=True)
    
    # 1. Générer les contrats
    print("\n1. Génération des contrats...")
    contrats = generer_contrats(N_CONTRATS)
    print(f"   ✓ {len(contrats)} contrats générés")
    
    # 2. Générer les sinistres pour chaque année
    print("\n2. Génération des sinistres...")
    all_sinistres = []
    
    for annee in ANNEES:
        print(f"   - Année {annee}...", end=" ")
        sinistres_annee = generer_sinistres(contrats, annee)
        all_sinistres.append(sinistres_annee)
        nb_sin = sinistres_annee['nb_sinistres'].sum()
        cout_tot = sinistres_annee['cout_sinistre'].sum()
        print(f"✓ {nb_sin} sinistres, {cout_tot:,.0f}€")
    
    # Concaténer toutes les années
    df_sinistres = pd.concat(all_sinistres, ignore_index=True)
    
    # 3. Créer le fichier d'exposition
    print("\n3. Création du fichier d'exposition...")
    df_exposition = df_sinistres[['id_contrat', 'annee', 'duree_contrat_jours']].copy()
    df_exposition['exposition'] = df_exposition['duree_contrat_jours'] / 365
    df_exposition = df_exposition.drop(columns=['duree_contrat_jours'])
    print(f"   ✓ Exposition totale: {df_exposition['exposition'].sum():,.1f} années")
    
    # 4. Créer le référentiel des zones
    print("\n4. Création du référentiel des zones...")
    df_zones = generer_zones_geo()
    print(f"   ✓ {len(df_zones)} départements référencés")
    
    # 5. Sauvegarder les fichiers
    print("\n5. Sauvegarde des fichiers CSV...")
    
    # Fichier sinistres
    df_sinistres.to_csv('data/sinistres_mrh.csv', index=False)
    print(f"   ✓ data/sinistres_mrh.csv ({len(df_sinistres)} lignes)")
    
    # Fichier exposition
    df_exposition.to_csv('data/exposition_mrh.csv', index=False)
    print(f"   ✓ data/exposition_mrh.csv ({len(df_exposition)} lignes)")
    
    # Fichier zones
    df_zones.to_csv('data/zones_geo.csv', index=False)
    print(f"   ✓ data/zones_geo.csv ({len(df_zones)} lignes)")
    
    # 6. Statistiques descriptives
    print("\n" + "=" * 60)
    print("STATISTIQUES DESCRIPTIVES")
    print("=" * 60)
    
    print(f"\n📊 Volume de données:")
    print(f"   - Contrats: {N_CONTRATS:,}")
    print(f"   - Années: {len(ANNEES)}")
    print(f"   - Observations: {len(df_sinistres):,}")
    
    print(f"\n📈 Sinistralité globale:")
    nb_sin_total = df_sinistres['nb_sinistres'].sum()
    cout_total = df_sinistres['cout_sinistre'].sum()
    expo_total = df_exposition['exposition'].sum()
    
    freq_obs = nb_sin_total / expo_total
    sev_obs = cout_total / nb_sin_total if nb_sin_total > 0 else 0
    prime_pure_obs = freq_obs * sev_obs
    
    print(f"   - Nombre de sinistres: {nb_sin_total:,}")
    print(f"   - Coût total: {cout_total:,.0f}€")
    print(f"   - Fréquence observée: {freq_obs:.2%}")
    print(f"   - Sévérité moyenne: {sev_obs:,.0f}€")
    print(f"   - Prime pure observée: {prime_pure_obs:,.0f}€")
    
    print(f"\n📍 Répartition par zone:")
    for zone in ['Rural', 'Periurbain', 'Urbain', 'Paris_IDF']:
        mask = df_sinistres['zone_geo'] == zone
        nb_obs = mask.sum() / len(ANNEES)
        freq_zone = df_sinistres.loc[mask, 'nb_sinistres'].sum() / df_exposition.loc[df_sinistres.loc[mask].index, 'exposition'].sum()
        print(f"   - {zone}: {nb_obs:,.0f} contrats, fréquence {freq_zone:.2%}")
    
    print("\n" + "=" * 60)
    print("✅ GÉNÉRATION TERMINÉE AVEC SUCCÈS")
    print("=" * 60)
    
    return df_sinistres, df_exposition, df_zones


if __name__ == "__main__":
    df_sinistres, df_exposition, df_zones = main()
