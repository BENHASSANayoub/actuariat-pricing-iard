"""
Module des Modèles Linéaires Généralisés (GLM) pour l'actuariat
================================================================

Implémentation des modèles GLM pour la tarification assurance :
- GLM Poisson pour la fréquence
- GLM Gamma pour la sévérité
- Gestion de la surdispersion

Auteur: Ayoub BENHASSAN
"""

import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy import stats
from typing import List, Dict, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')


class GLMFrequence:
    """
    Modèle GLM Poisson pour la fréquence des sinistres.
    
    Le modèle Poisson est adapté aux données de comptage (nombre de sinistres).
    L'offset log(exposition) permet de modéliser un taux plutôt qu'un comptage brut.
    
    Formule: ln(E[N]) = ln(Exposition) + β₀ + β₁X₁ + ... + βₚXₚ
    """
    
    def __init__(self):
        self.model = None
        self.result = None
        self.formula = None
        self.features = None
        
    def fit(self, df: pd.DataFrame, 
            target: str = 'nb_sinistres',
            features: List[str] = None,
            offset_col: str = 'log_exposition',
            formula: str = None) -> 'GLMFrequence':
        """
        Ajuste le modèle GLM Poisson.
        
        Parameters
        ----------
        df : pd.DataFrame
            Données d'entraînement
        target : str
            Colonne cible (nombre de sinistres)
        features : List[str]
            Liste des variables explicatives
        offset_col : str
            Colonne de l'offset (log de l'exposition)
        formula : str
            Formule Patsy (optionnel, prioritaire sur features)
            
        Returns
        -------
        self
        """
        self.features = features
        
        if formula:
            self.formula = formula
        elif features:
            # Construire la formule automatiquement
            # Ajouter C() pour les variables catégorielles
            terms = []
            for f in features:
                if df[f].dtype == 'object' or df[f].dtype.name == 'category':
                    terms.append(f'C({f})')
                else:
                    terms.append(f)
            self.formula = f"{target} ~ " + " + ".join(terms)
        else:
            raise ValueError("Fournir 'features' ou 'formula'")
        
        print(f"📊 Formule: {self.formula}")
        
        # Ajuster le modèle
        self.model = smf.glm(
            formula=self.formula,
            data=df,
            family=sm.families.Poisson(link=sm.families.links.Log()),
            offset=df[offset_col]
        )
        self.result = self.model.fit()
        
        print(f"✓ Modèle ajusté")
        print(f"  - AIC: {self.result.aic:.1f}")
        print(f"  - Deviance: {self.result.deviance:.1f}")
        
        return self
    
    def summary(self) -> None:
        """Affiche le résumé du modèle."""
        if self.result:
            print(self.result.summary())
        else:
            print("Modèle non ajusté. Appelez fit() d'abord.")
    
    def get_coefficients(self) -> pd.DataFrame:
        """
        Retourne les coefficients avec leurs statistiques.
        
        Returns
        -------
        pd.DataFrame
            Tableau des coefficients
        """
        if not self.result:
            raise ValueError("Modèle non ajusté")
        
        coef_df = pd.DataFrame({
            'coefficient': self.result.params,
            'std_error': self.result.bse,
            'z_value': self.result.tvalues,
            'p_value': self.result.pvalues,
            'significatif': self.result.pvalues < 0.05
        })
        
        return coef_df.round(4)
    
    def get_relativites(self) -> pd.DataFrame:
        """
        Calcule les relativités (exp(β)).
        
        Les relativités s'interprètent de façon multiplicative :
        - Relativité = 1.30 → +30% de risque vs référence
        - Relativité = 0.80 → -20% de risque vs référence
        
        Returns
        -------
        pd.DataFrame
            Tableau des relativités avec IC 95%
        """
        if not self.result:
            raise ValueError("Modèle non ajusté")
        
        # Calculer les relativités
        relativites = np.exp(self.result.params)
        
        # Intervalles de confiance
        conf_int = self.result.conf_int()
        ic_lower = np.exp(conf_int[0])
        ic_upper = np.exp(conf_int[1])
        
        rel_df = pd.DataFrame({
            'relativite': relativites,
            'IC_95_lower': ic_lower,
            'IC_95_upper': ic_upper,
            'impact_pct': (relativites - 1) * 100
        })
        
        return rel_df.round(4)
    
    def predict(self, df: pd.DataFrame, 
                offset_col: str = 'log_exposition',
                type: str = 'response') -> np.ndarray:
        """
        Prédit la fréquence.
        
        Parameters
        ----------
        df : pd.DataFrame
            Données pour prédiction
        offset_col : str
            Colonne de l'offset
        type : str
            'response' pour la fréquence, 'linear' pour le prédicteur linéaire
            
        Returns
        -------
        np.ndarray
            Prédictions
        """
        if not self.result:
            raise ValueError("Modèle non ajusté")
        
        # Ajouter l'offset aux prédictions
        linear_pred = self.result.predict(df)
        
        if type == 'linear':
            return linear_pred
        else:
            return linear_pred  # statsmodels retourne déjà la réponse
    
    def diagnostic_surdispersion(self, df: pd.DataFrame) -> Dict:
        """
        Diagnostique la surdispersion du modèle Poisson.
        
        La surdispersion se produit quand Var(Y) > E[Y].
        Le paramètre φ = Σ(résidus de Pearson)² / df
        - φ ≈ 1 : pas de surdispersion
        - φ > 1.5 : surdispersion significative
        
        Parameters
        ----------
        df : pd.DataFrame
            Données utilisées pour l'ajustement
            
        Returns
        -------
        Dict
            Diagnostic de surdispersion
        """
        if not self.result:
            raise ValueError("Modèle non ajusté")
        
        # Résidus de Pearson
        residuals_pearson = self.result.resid_pearson
        
        # Paramètre de dispersion
        df_residual = self.result.df_resid
        phi = np.sum(residuals_pearson**2) / df_residual
        
        # Test formel (approximation)
        # Sous H0 (pas de surdispersion), phi ~ 1
        chi2_stat = np.sum(residuals_pearson**2)
        p_value = 1 - stats.chi2.cdf(chi2_stat, df_residual)
        
        diagnostic = {
            'phi': phi,
            'chi2_statistic': chi2_stat,
            'df_residual': df_residual,
            'p_value': p_value,
            'surdispersion': phi > 1.5,
            'interpretation': self._interpreter_surdispersion(phi)
        }
        
        print("\n📊 DIAGNOSTIC DE SURDISPERSION")
        print("=" * 40)
        print(f"Paramètre de dispersion φ = {phi:.3f}")
        print(f"Degrés de liberté = {df_residual}")
        print(f"Statistique χ² = {chi2_stat:.1f}")
        print(f"p-value = {p_value:.4f}")
        print(f"\n→ {diagnostic['interpretation']}")
        
        return diagnostic
    
    def _interpreter_surdispersion(self, phi: float) -> str:
        """Interprète le paramètre de dispersion."""
        if phi <= 1.1:
            return "✓ Pas de surdispersion - Modèle Poisson adapté"
        elif phi <= 1.5:
            return "⚠ Surdispersion légère - Poisson acceptable"
        else:
            return "❌ Surdispersion significative - Utiliser Quasi-Poisson ou Binomiale Négative"


class GLMSeverite:
    """
    Modèle GLM Gamma pour la sévérité des sinistres.
    
    Le modèle Gamma est adapté aux coûts de sinistres car :
    - Valeurs strictement positives
    - Distribution asymétrique à droite
    - Variance proportionnelle au carré de la moyenne
    
    IMPORTANT: Ajusté uniquement sur les sinistres (coût > 0)
    
    Formule: ln(E[Coût]) = β₀ + β₁X₁ + ... + βₚXₚ
    """
    
    def __init__(self):
        self.model = None
        self.result = None
        self.formula = None
        self.features = None
        
    def fit(self, df: pd.DataFrame,
            target: str = 'cout_sinistre',
            features: List[str] = None,
            formula: str = None,
            filter_sinistres: bool = True) -> 'GLMSeverite':
        """
        Ajuste le modèle GLM Gamma.
        
        Parameters
        ----------
        df : pd.DataFrame
            Données d'entraînement
        target : str
            Colonne cible (coût du sinistre)
        features : List[str]
            Liste des variables explicatives
        formula : str
            Formule Patsy (optionnel)
        filter_sinistres : bool
            Filtrer uniquement les sinistres (coût > 0)
            
        Returns
        -------
        self
        """
        # Filtrer les sinistres si demandé
        if filter_sinistres:
            df_sin = df[df[target] > 0].copy()
            print(f"✓ Filtre sinistres: {len(df_sin):,} observations (coût > 0)")
        else:
            df_sin = df.copy()
        
        self.features = features
        
        if formula:
            self.formula = formula
        elif features:
            terms = []
            for f in features:
                if df_sin[f].dtype == 'object' or df_sin[f].dtype.name == 'category':
                    terms.append(f'C({f})')
                else:
                    terms.append(f)
            self.formula = f"{target} ~ " + " + ".join(terms)
        else:
            raise ValueError("Fournir 'features' ou 'formula'")
        
        print(f"📊 Formule: {self.formula}")
        
        # Ajuster le modèle Gamma avec lien log
        self.model = smf.glm(
            formula=self.formula,
            data=df_sin,
            family=sm.families.Gamma(link=sm.families.links.Log())
        )
        self.result = self.model.fit()
        
        print(f"✓ Modèle ajusté")
        print(f"  - AIC: {self.result.aic:.1f}")
        print(f"  - Deviance: {self.result.deviance:.1f}")
        
        return self
    
    def summary(self) -> None:
        """Affiche le résumé du modèle."""
        if self.result:
            print(self.result.summary())
        else:
            print("Modèle non ajusté. Appelez fit() d'abord.")
    
    def get_coefficients(self) -> pd.DataFrame:
        """Retourne les coefficients avec leurs statistiques."""
        if not self.result:
            raise ValueError("Modèle non ajusté")
        
        coef_df = pd.DataFrame({
            'coefficient': self.result.params,
            'std_error': self.result.bse,
            'z_value': self.result.tvalues,
            'p_value': self.result.pvalues,
            'significatif': self.result.pvalues < 0.05
        })
        
        return coef_df.round(4)
    
    def get_relativites(self) -> pd.DataFrame:
        """Calcule les relativités (exp(β))."""
        if not self.result:
            raise ValueError("Modèle non ajusté")
        
        relativites = np.exp(self.result.params)
        conf_int = self.result.conf_int()
        ic_lower = np.exp(conf_int[0])
        ic_upper = np.exp(conf_int[1])
        
        rel_df = pd.DataFrame({
            'relativite': relativites,
            'IC_95_lower': ic_lower,
            'IC_95_upper': ic_upper,
            'impact_pct': (relativites - 1) * 100
        })
        
        return rel_df.round(4)
    
    def predict(self, df: pd.DataFrame, type: str = 'response') -> np.ndarray:
        """Prédit la sévérité."""
        if not self.result:
            raise ValueError("Modèle non ajusté")
        
        return self.result.predict(df)


class GLMQuasiPoisson:
    """
    Modèle Quasi-Poisson pour gérer la surdispersion.
    
    Le Quasi-Poisson garde les mêmes coefficients que Poisson
    mais ajuste les erreurs standards par un facteur √φ.
    """
    
    def __init__(self):
        self.model = None
        self.result = None
        self.formula = None
        self.phi = None
        
    def fit(self, df: pd.DataFrame,
            target: str = 'nb_sinistres',
            features: List[str] = None,
            offset_col: str = 'log_exposition',
            formula: str = None) -> 'GLMQuasiPoisson':
        """Ajuste le modèle Quasi-Poisson."""
        
        self.features = features
        
        if formula:
            self.formula = formula
        elif features:
            terms = []
            for f in features:
                if df[f].dtype == 'object' or df[f].dtype.name == 'category':
                    terms.append(f'C({f})')
                else:
                    terms.append(f)
            self.formula = f"{target} ~ " + " + ".join(terms)
        
        print(f"📊 Formule: {self.formula}")
        
        # Ajuster d'abord un Poisson standard
        model_poisson = smf.glm(
            formula=self.formula,
            data=df,
            family=sm.families.Poisson(),
            offset=df[offset_col]
        )
        result_poisson = model_poisson.fit()
        
        # Calculer le paramètre de dispersion
        self.phi = np.sum(result_poisson.resid_pearson**2) / result_poisson.df_resid
        
        # Utiliser la famille NegativeBinomial pour simuler Quasi-Poisson
        # ou ajuster manuellement les erreurs standards
        self.model = model_poisson
        self.result = result_poisson
        
        # Corriger les erreurs standards
        self.result.bse_corrected = self.result.bse * np.sqrt(self.phi)
        
        print(f"✓ Modèle Quasi-Poisson ajusté")
        print(f"  - Paramètre de dispersion φ = {self.phi:.3f}")
        print(f"  - Erreurs standards multipliées par √φ = {np.sqrt(self.phi):.3f}")
        
        return self
    
    def get_relativites(self) -> pd.DataFrame:
        """Calcule les relativités avec erreurs standards corrigées."""
        if not self.result:
            raise ValueError("Modèle non ajusté")
        
        relativites = np.exp(self.result.params)
        
        # IC corrigés pour la surdispersion
        z_crit = 1.96
        ic_lower = np.exp(self.result.params - z_crit * self.result.bse_corrected)
        ic_upper = np.exp(self.result.params + z_crit * self.result.bse_corrected)
        
        rel_df = pd.DataFrame({
            'relativite': relativites,
            'IC_95_lower': ic_lower,
            'IC_95_upper': ic_upper,
            'impact_pct': (relativites - 1) * 100
        })
        
        return rel_df.round(4)


def calculer_prime_pure(df: pd.DataFrame,
                        model_freq: GLMFrequence,
                        model_sev: GLMSeverite,
                        offset_col: str = 'log_exposition') -> pd.Series:
    """
    Calcule la prime pure = Fréquence × Sévérité.
    
    Parameters
    ----------
    df : pd.DataFrame
        Données pour le calcul
    model_freq : GLMFrequence
        Modèle de fréquence ajusté
    model_sev : GLMSeverite
        Modèle de sévérité ajusté
    offset_col : str
        Colonne de l'offset
        
    Returns
    -------
    pd.Series
        Prime pure par observation
    """
    # Prédire la fréquence (sans l'offset, c'est un taux)
    freq_pred = model_freq.predict(df, offset_col=offset_col)
    
    # Prédire la sévérité
    sev_pred = model_sev.predict(df)
    
    # Prime pure = fréquence × sévérité
    prime_pure = freq_pred * sev_pred
    
    return prime_pure


def comparer_modeles(*models, names: List[str] = None) -> pd.DataFrame:
    """
    Compare plusieurs modèles GLM.
    
    Parameters
    ----------
    *models
        Modèles à comparer
    names : List[str]
        Noms des modèles
        
    Returns
    -------
    pd.DataFrame
        Tableau comparatif
    """
    if names is None:
        names = [f"Modèle {i+1}" for i in range(len(models))]
    
    comparison = []
    for name, model in zip(names, models):
        if model.result:
            comparison.append({
                'Modèle': name,
                'AIC': model.result.aic,
                'BIC': model.result.bic,
                'Deviance': model.result.deviance,
                'Log-Likelihood': model.result.llf,
                'Nb paramètres': len(model.result.params)
            })
    
    df_comp = pd.DataFrame(comparison)
    df_comp = df_comp.sort_values('AIC')
    
    return df_comp


if __name__ == "__main__":
    # Test du module
    print("Test du module glm_models...")
    
    from data_preparation import prepare_data
    
    # Charger les données
    df = prepare_data('data/sinistres_mrh.csv', 'data/exposition_mrh.csv')
    
    # Variables explicatives
    features = ['type_logement', 'zone_geo', 'age_groupe', 'surface_groupe', 'etage']
    
    # Modèle de fréquence
    print("\n" + "="*50)
    print("MODÈLE DE FRÉQUENCE (Poisson)")
    print("="*50)
    
    model_freq = GLMFrequence()
    model_freq.fit(df, features=features)
    
    print("\nRelativités de fréquence:")
    print(model_freq.get_relativites())
    
    # Diagnostic de surdispersion
    model_freq.diagnostic_surdispersion(df)
    
    # Modèle de sévérité
    print("\n" + "="*50)
    print("MODÈLE DE SÉVÉRITÉ (Gamma)")
    print("="*50)
    
    model_sev = GLMSeverite()
    model_sev.fit(df, features=features)
    
    print("\nRelativités de sévérité:")
    print(model_sev.get_relativites())
    
    # Prime pure
    print("\n" + "="*50)
    print("PRIME PURE")
    print("="*50)
    
    df['prime_pure_pred'] = calculer_prime_pure(df, model_freq, model_sev)
    print(f"Prime pure moyenne prédite: {df['prime_pure_pred'].mean():.2f}€")
    print(f"Prime pure moyenne observée: {df['prime_pure'].mean():.2f}€")
