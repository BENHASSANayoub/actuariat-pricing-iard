"""
Module de préparation des données pour l'actuariat pricing
===========================================================

Fonctions pour charger, nettoyer et préparer les données
avant la modélisation GLM et Machine Learning.

Auteur: Ayoub BENHASSAN
"""

import pandas as pd
import numpy as np
from typing import Tuple, List, Optional
import warnings
warnings.filterwarnings('ignore')


def charger_donnees(path_sinistres: str, path_exposition: str) -> pd.DataFrame:
    """
    Charge et fusionne les données de sinistres et d'exposition.
    
    Parameters
    ----------
    path_sinistres : str
        Chemin vers le fichier de sinistres
    path_exposition : str
        Chemin vers le fichier d'exposition
        
    Returns
    -------
    pd.DataFrame
        DataFrame fusionné avec sinistres et exposition
    """
    # Charger les fichiers
    df_sin = pd.read_csv(path_sinistres)
    df_expo = pd.read_csv(path_exposition)
    
    # Fusionner sur id_contrat et annee
    df = df_sin.merge(df_expo, on=['id_contrat', 'annee'], how='left')
    
    print(f"✓ Données chargées: {len(df):,} observations")
    print(f"  - Sinistres: {df['nb_sinistres'].sum():,}")
    print(f"  - Exposition totale: {df['exposition'].sum():,.1f} années")
    
    return df


def calculer_exposition(df: pd.DataFrame, col_duree: str = 'duree_contrat_jours') -> pd.DataFrame:
    """
    Calcule l'exposition en années à partir de la durée en jours.
    
    Parameters
    ----------
    df : pd.DataFrame
        DataFrame avec la colonne de durée
    col_duree : str
        Nom de la colonne contenant la durée en jours
        
    Returns
    -------
    pd.DataFrame
        DataFrame avec la colonne 'exposition' ajoutée
    """
    df = df.copy()
    df['exposition'] = df[col_duree] / 365
    df['log_exposition'] = np.log(df['exposition'])
    
    return df


def discretiser_variable(df: pd.DataFrame, 
                         col: str, 
                         bins: List, 
                         labels: List,
                         col_output: Optional[str] = None) -> pd.DataFrame:
    """
    Discrétise une variable continue en classes.
    
    Parameters
    ----------
    df : pd.DataFrame
        DataFrame source
    col : str
        Nom de la colonne à discrétiser
    bins : List
        Bornes des classes
    labels : List
        Labels des classes
    col_output : str, optional
        Nom de la colonne de sortie (défaut: col + '_groupe')
        
    Returns
    -------
    pd.DataFrame
        DataFrame avec la nouvelle colonne
    """
    df = df.copy()
    
    if col_output is None:
        col_output = f"{col}_groupe"
    
    df[col_output] = pd.cut(df[col], bins=bins, labels=labels, include_lowest=True)
    
    return df


def traiter_valeurs_manquantes(df: pd.DataFrame, 
                                strategy: str = 'median') -> pd.DataFrame:
    """
    Traite les valeurs manquantes.
    
    Parameters
    ----------
    df : pd.DataFrame
        DataFrame avec potentiellement des valeurs manquantes
    strategy : str
        Stratégie: 'median', 'mean', 'mode', 'drop'
        
    Returns
    -------
    pd.DataFrame
        DataFrame sans valeurs manquantes
    """
    df = df.copy()
    
    # Compter les valeurs manquantes
    missing = df.isnull().sum()
    missing = missing[missing > 0]
    
    if len(missing) > 0:
        print(f"⚠ Valeurs manquantes détectées:")
        for col, count in missing.items():
            print(f"  - {col}: {count} ({count/len(df)*100:.1f}%)")
    
    # Appliquer la stratégie
    for col in df.columns:
        if df[col].isnull().sum() > 0:
            if df[col].dtype in ['int64', 'float64']:
                if strategy == 'median':
                    df[col].fillna(df[col].median(), inplace=True)
                elif strategy == 'mean':
                    df[col].fillna(df[col].mean(), inplace=True)
            else:
                df[col].fillna(df[col].mode()[0], inplace=True)
    
    return df


def traiter_outliers(df: pd.DataFrame, 
                     col: str, 
                     method: str = 'winsorize',
                     lower_percentile: float = 0.01,
                     upper_percentile: float = 0.99) -> pd.DataFrame:
    """
    Traite les valeurs aberrantes (outliers).
    
    Parameters
    ----------
    df : pd.DataFrame
        DataFrame source
    col : str
        Colonne à traiter
    method : str
        Méthode: 'winsorize', 'clip', 'log'
    lower_percentile : float
        Percentile inférieur pour winsorization
    upper_percentile : float
        Percentile supérieur pour winsorization
        
    Returns
    -------
    pd.DataFrame
        DataFrame avec outliers traités
    """
    df = df.copy()
    
    if method == 'winsorize':
        lower = df[col].quantile(lower_percentile)
        upper = df[col].quantile(upper_percentile)
        df[col] = df[col].clip(lower=lower, upper=upper)
        print(f"✓ Winsorization {col}: [{lower:.2f}, {upper:.2f}]")
        
    elif method == 'clip':
        lower = df[col].quantile(lower_percentile)
        upper = df[col].quantile(upper_percentile)
        df[col] = df[col].clip(lower=lower, upper=upper)
        
    elif method == 'log':
        df[f'{col}_log'] = np.log1p(df[col])
    
    return df


def encoder_categoriques(df: pd.DataFrame, 
                         cols: List[str],
                         method: str = 'dummy',
                         drop_first: bool = True) -> pd.DataFrame:
    """
    Encode les variables catégorielles.
    
    Parameters
    ----------
    df : pd.DataFrame
        DataFrame source
    cols : List[str]
        Colonnes à encoder
    method : str
        Méthode: 'dummy', 'label', 'frequency'
    drop_first : bool
        Supprimer la première modalité (éviter colinéarité)
        
    Returns
    -------
    pd.DataFrame
        DataFrame avec variables encodées
    """
    df = df.copy()
    
    if method == 'dummy':
        df = pd.get_dummies(df, columns=cols, drop_first=drop_first)
        
    elif method == 'label':
        from sklearn.preprocessing import LabelEncoder
        for col in cols:
            le = LabelEncoder()
            df[f'{col}_encoded'] = le.fit_transform(df[col].astype(str))
            
    elif method == 'frequency':
        for col in cols:
            freq = df[col].value_counts(normalize=True)
            df[f'{col}_freq'] = df[col].map(freq)
    
    return df


def prepare_data(path_sinistres: str, 
                 path_exposition: str,
                 discretize: bool = True) -> pd.DataFrame:
    """
    Pipeline complet de préparation des données.
    
    Parameters
    ----------
    path_sinistres : str
        Chemin vers le fichier de sinistres
    path_exposition : str
        Chemin vers le fichier d'exposition
    discretize : bool
        Appliquer la discrétisation des variables continues
        
    Returns
    -------
    pd.DataFrame
        DataFrame prêt pour la modélisation
    """
    print("=" * 50)
    print("PRÉPARATION DES DONNÉES")
    print("=" * 50)
    
    # 1. Charger les données
    print("\n1. Chargement des données...")
    df = charger_donnees(path_sinistres, path_exposition)
    
    # 2. Traiter les valeurs manquantes
    print("\n2. Traitement des valeurs manquantes...")
    df = traiter_valeurs_manquantes(df)
    
    # 3. Calculer l'exposition et log_exposition
    print("\n3. Calcul de l'exposition...")
    if 'log_exposition' not in df.columns:
        df['log_exposition'] = np.log(df['exposition'])
    print(f"   ✓ Log exposition calculé")
    
    # 4. Discrétisation (si les groupes n'existent pas déjà)
    if discretize:
        print("\n4. Discrétisation des variables...")
        
        if 'age_groupe' not in df.columns and 'age_assure' in df.columns:
            df = discretiser_variable(df, 'age_assure', 
                                     bins=[0, 30, 45, 60, 100],
                                     labels=['18-30', '31-45', '46-60', '61+'],
                                     col_output='age_groupe')
            
        if 'surface_groupe' not in df.columns and 'surface_m2' in df.columns:
            df = discretiser_variable(df, 'surface_m2',
                                     bins=[0, 50, 100, 150, 500],
                                     labels=['<50m2', '50-100m2', '100-150m2', '>150m2'],
                                     col_output='surface_groupe')
            
        if 'anciennete_groupe' not in df.columns and 'anciennete_batiment' in df.columns:
            df = discretiser_variable(df, 'anciennete_batiment',
                                     bins=[0, 10, 30, 200],
                                     labels=['<10ans', '10-30ans', '>30ans'],
                                     col_output='anciennete_groupe')
        
        print("   ✓ Variables discrétisées")
    
    # 5. Traiter les outliers sur la sévérité
    print("\n5. Traitement des outliers...")
    if 'cout_sinistre' in df.columns:
        # Seulement sur les sinistres (coût > 0)
        mask = df['cout_sinistre'] > 0
        upper = df.loc[mask, 'cout_sinistre'].quantile(0.99)
        df.loc[mask, 'cout_sinistre'] = df.loc[mask, 'cout_sinistre'].clip(upper=upper)
        print(f"   ✓ Sévérité plafonnée à {upper:,.0f}€")
    
    # 6. Créer la variable cible pour la sévérité (coût moyen par sinistre)
    print("\n6. Création des variables cibles...")
    df['cout_moyen'] = np.where(df['nb_sinistres'] > 0,
                                 df['cout_sinistre'] / df['nb_sinistres'],
                                 0)
    df['frequence'] = df['nb_sinistres'] / df['exposition']
    df['prime_pure'] = df['cout_sinistre'] / df['exposition']
    print("   ✓ Variables cibles créées (cout_moyen, frequence, prime_pure)")
    
    print("\n" + "=" * 50)
    print("✅ PRÉPARATION TERMINÉE")
    print(f"   Observations: {len(df):,}")
    print(f"   Variables: {len(df.columns)}")
    print("=" * 50)
    
    return df


def split_train_test(df: pd.DataFrame,
                     test_size: float = 0.2,
                     random_state: int = 42,
                     stratify_col: Optional[str] = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Sépare les données en train/test.
    
    Parameters
    ----------
    df : pd.DataFrame
        DataFrame à séparer
    test_size : float
        Proportion du test set
    random_state : int
        Seed pour reproductibilité
    stratify_col : str, optional
        Colonne pour stratification
        
    Returns
    -------
    Tuple[pd.DataFrame, pd.DataFrame]
        (df_train, df_test)
    """
    from sklearn.model_selection import train_test_split
    
    if stratify_col and stratify_col in df.columns:
        stratify = df[stratify_col]
    else:
        stratify = None
    
    df_train, df_test = train_test_split(df, 
                                         test_size=test_size,
                                         random_state=random_state,
                                         stratify=stratify)
    
    print(f"✓ Split train/test: {len(df_train):,} / {len(df_test):,}")
    
    return df_train, df_test


def get_features_target(df: pd.DataFrame,
                        features: List[str],
                        target: str,
                        as_dummies: bool = False) -> Tuple[pd.DataFrame, pd.Series]:
    """
    Extrait les features et la target.
    
    Parameters
    ----------
    df : pd.DataFrame
        DataFrame source
    features : List[str]
        Liste des colonnes features
    target : str
        Nom de la colonne target
    as_dummies : bool
        Convertir les catégorielles en dummies
        
    Returns
    -------
    Tuple[pd.DataFrame, pd.Series]
        (X, y)
    """
    X = df[features].copy()
    y = df[target].copy()
    
    if as_dummies:
        # Identifier les colonnes catégorielles
        cat_cols = X.select_dtypes(include=['object', 'category']).columns.tolist()
        if cat_cols:
            X = pd.get_dummies(X, columns=cat_cols, drop_first=True)
    
    return X, y


# =============================================================================
# STATISTIQUES DESCRIPTIVES
# =============================================================================

def statistiques_sinistralite(df: pd.DataFrame, 
                              group_by: Optional[List[str]] = None) -> pd.DataFrame:
    """
    Calcule les statistiques de sinistralité par groupe.
    
    Parameters
    ----------
    df : pd.DataFrame
        DataFrame avec les données
    group_by : List[str], optional
        Colonnes de regroupement
        
    Returns
    -------
    pd.DataFrame
        Statistiques de sinistralité
    """
    if group_by is None:
        # Statistiques globales
        stats = pd.DataFrame({
            'nb_observations': [len(df)],
            'exposition_totale': [df['exposition'].sum()],
            'nb_sinistres': [df['nb_sinistres'].sum()],
            'cout_total': [df['cout_sinistre'].sum()],
        })
        stats['frequence'] = stats['nb_sinistres'] / stats['exposition_totale']
        stats['severite'] = stats['cout_total'] / stats['nb_sinistres']
        stats['prime_pure'] = stats['cout_total'] / stats['exposition_totale']
        
    else:
        # Statistiques par groupe
        stats = df.groupby(group_by).agg({
            'id_contrat': 'count',
            'exposition': 'sum',
            'nb_sinistres': 'sum',
            'cout_sinistre': 'sum'
        }).rename(columns={
            'id_contrat': 'nb_observations',
            'exposition': 'exposition_totale',
            'cout_sinistre': 'cout_total'
        })
        
        stats['frequence'] = stats['nb_sinistres'] / stats['exposition_totale']
        stats['severite'] = stats['cout_total'] / stats['nb_sinistres']
        stats['prime_pure'] = stats['cout_total'] / stats['exposition_totale']
        
        # Remplacer les inf/nan par 0
        stats = stats.replace([np.inf, -np.inf], 0).fillna(0)
    
    return stats


if __name__ == "__main__":
    # Test du module
    print("Test du module data_preparation...")
    
    # Charger et préparer les données
    df = prepare_data('data/sinistres_mrh.csv', 'data/exposition_mrh.csv')
    
    # Statistiques globales
    print("\nStatistiques globales:")
    stats = statistiques_sinistralite(df)
    print(stats.T)
    
    # Statistiques par zone
    print("\nStatistiques par zone géographique:")
    stats_zone = statistiques_sinistralite(df, group_by=['zone_geo'])
    print(stats_zone)
