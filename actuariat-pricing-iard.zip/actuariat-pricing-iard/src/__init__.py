"""
Module Actuariat Pricing IARD
=============================

Modules disponibles:
- data_preparation : Préparation et nettoyage des données
- glm_models : Modèles GLM (Poisson, Gamma)
- ml_models : Modèles Machine Learning (RF, XGBoost)
- zonier : Construction du zonier et analyse d'impact

Auteur: Ayoub BENHASSAN
"""

from .data_preparation import (
    prepare_data,
    charger_donnees,
    split_train_test,
    statistiques_sinistralite
)

from .glm_models import (
    GLMFrequence,
    GLMSeverite,
    GLMQuasiPoisson,
    calculer_prime_pure
)

from .ml_models import (
    RandomForestModel,
    XGBoostModel,
    evaluer_modele
)

from .zonier import (
    construire_zonier,
    appliquer_zonier,
    analyse_impact
)

__version__ = "1.0.0"
__author__ = "Ayoub BENHASSAN"
