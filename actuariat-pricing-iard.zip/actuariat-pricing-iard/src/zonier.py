"""
Module Zonier et Analyse d'Impact
==================================

Construction du zonier tarifaire et analyse de l'impact
des révisions de tarifs sur le portefeuille.

Auteur: Ayoub BENHASSAN
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Tuple, Optional
from scipy import stats
import warnings
warnings.filterwarnings('ignore')


def construire_zonier(df: pd.DataFrame,
                      col_departement: str = 'departement',
                      col_sinistres: str = 'nb_sinistres',
                      col_cout: str = 'cout_sinistre',
                      col_exposition: str = 'exposition',
                      n_zones: int = 5,
                      methode: str = 'quantile') -> pd.DataFrame:
    """
    Construit un zonier tarifaire basé sur la sinistralité par département.
    
    Le zonier regroupe les départements en zones homogènes selon leur
    niveau de risque (fréquence × sévérité = prime pure).
    
    Parameters
    ----------
    df : pd.DataFrame
        Données de sinistralité
    col_departement : str
        Colonne du département
    col_sinistres : str
        Colonne du nombre de sinistres
    col_cout : str
        Colonne du coût des sinistres
    col_exposition : str
        Colonne de l'exposition
    n_zones : int
        Nombre de zones à créer
    methode : str
        'quantile' ou 'kmeans'
        
    Returns
    -------
    pd.DataFrame
        Zonier avec relativités par département
    """
    print("=" * 50)
    print("CONSTRUCTION DU ZONIER")
    print("=" * 50)
    
    # Agréger par département
    stats_dept = df.groupby(col_departement).agg({
        col_sinistres: 'sum',
        col_cout: 'sum',
        col_exposition: 'sum',
        'id_contrat': 'count'
    }).rename(columns={'id_contrat': 'nb_contrats'})
    
    # Calculer les indicateurs
    stats_dept['frequence'] = stats_dept[col_sinistres] / stats_dept[col_exposition]
    stats_dept['severite'] = np.where(
        stats_dept[col_sinistres] > 0,
        stats_dept[col_cout] / stats_dept[col_sinistres],
        0
    )
    stats_dept['prime_pure'] = stats_dept[col_cout] / stats_dept[col_exposition]
    stats_dept['loss_ratio'] = stats_dept[col_cout] / (stats_dept[col_exposition] * stats_dept['prime_pure'].mean())
    
    # Calculer la prime pure moyenne (référence)
    prime_pure_moyenne = stats_dept['prime_pure'].mean()
    stats_dept['relativite_brute'] = stats_dept['prime_pure'] / prime_pure_moyenne
    
    # Créer les zones
    if methode == 'quantile':
        # Méthode des quantiles
        stats_dept['zone'] = pd.qcut(
            stats_dept['relativite_brute'],
            q=n_zones,
            labels=[f'Zone_{i+1}' for i in range(n_zones)]
        )
    elif methode == 'kmeans':
        from sklearn.cluster import KMeans
        kmeans = KMeans(n_clusters=n_zones, random_state=42)
        stats_dept['zone'] = kmeans.fit_predict(stats_dept[['relativite_brute']])
        stats_dept['zone'] = stats_dept['zone'].apply(lambda x: f'Zone_{x+1}')
    
    # Calculer les relativités par zone
    zonier_zone = stats_dept.groupby('zone').agg({
        col_sinistres: 'sum',
        col_cout: 'sum',
        col_exposition: 'sum',
        'nb_contrats': 'sum'
    })
    zonier_zone['prime_pure_zone'] = zonier_zone[col_cout] / zonier_zone[col_exposition]
    zonier_zone['relativite_zone'] = zonier_zone['prime_pure_zone'] / prime_pure_moyenne
    
    # Assigner la relativité zone à chaque département
    zone_relativites = zonier_zone['relativite_zone'].to_dict()
    stats_dept['relativite_zone'] = stats_dept['zone'].map(zone_relativites)
    
    # Lisser les relativités (credibility weighting)
    # Plus un département a d'exposition, plus on fait confiance à sa relativité propre
    credibility_factor = 1000  # Exposition nécessaire pour 100% de crédibilité
    stats_dept['credibilite'] = stats_dept[col_exposition] / (stats_dept[col_exposition] + credibility_factor)
    stats_dept['relativite_lissee'] = (
        stats_dept['credibilite'] * stats_dept['relativite_brute'] +
        (1 - stats_dept['credibilite']) * stats_dept['relativite_zone']
    )
    
    # Afficher le résumé
    print(f"\n✓ {len(stats_dept)} départements analysés")
    print(f"✓ {n_zones} zones créées")
    print(f"\nPrime pure moyenne de référence: {prime_pure_moyenne:.2f}€")
    
    print("\n📊 RÉSUMÉ PAR ZONE:")
    print("-" * 60)
    summary = stats_dept.groupby('zone').agg({
        'nb_contrats': 'sum',
        col_exposition: 'sum',
        'prime_pure': 'mean',
        'relativite_zone': 'first'
    }).round(3)
    print(summary)
    
    return stats_dept.reset_index()


def appliquer_zonier(df: pd.DataFrame,
                     zonier: pd.DataFrame,
                     col_departement: str = 'departement') -> pd.DataFrame:
    """
    Applique le zonier aux données.
    
    Parameters
    ----------
    df : pd.DataFrame
        Données à enrichir
    zonier : pd.DataFrame
        Zonier avec les relativités
    col_departement : str
        Colonne de jointure
        
    Returns
    -------
    pd.DataFrame
        Données enrichies avec la zone et la relativité
    """
    # Sélectionner les colonnes utiles du zonier
    zonier_mapping = zonier[[col_departement, 'zone', 'relativite_lissee']].copy()
    zonier_mapping = zonier_mapping.rename(columns={'relativite_lissee': 'relativite_geo'})
    
    # Joindre
    df_enrichi = df.merge(zonier_mapping, on=col_departement, how='left')
    
    # Remplir les valeurs manquantes avec la relativité moyenne
    df_enrichi['relativite_geo'] = df_enrichi['relativite_geo'].fillna(1.0)
    df_enrichi['zone'] = df_enrichi['zone'].fillna('Zone_3')  # Zone médiane par défaut
    
    print(f"✓ Zonier appliqué à {len(df_enrichi):,} observations")
    
    return df_enrichi


def analyse_impact(df: pd.DataFrame,
                   col_prime_actuelle: str = 'prime_actuelle',
                   col_prime_nouvelle: str = 'prime_nouvelle',
                   segments: List[str] = None) -> Dict:
    """
    Analyse l'impact d'une révision tarifaire.
    
    Compare l'ancien et le nouveau tarif pour identifier :
    - Les gagnants et perdants
    - L'impact par segment
    - L'évolution du loss ratio prévisionnel
    
    Parameters
    ----------
    df : pd.DataFrame
        Données avec les deux tarifs
    col_prime_actuelle : str
        Colonne du tarif actuel
    col_prime_nouvelle : str
        Colonne du nouveau tarif
    segments : List[str]
        Colonnes de segmentation pour l'analyse
        
    Returns
    -------
    Dict
        Résultats de l'analyse d'impact
    """
    print("=" * 50)
    print("ANALYSE D'IMPACT TARIFAIRE")
    print("=" * 50)
    
    df = df.copy()
    
    # Calculer la variation
    df['variation_prime'] = df[col_prime_nouvelle] - df[col_prime_actuelle]
    df['variation_pct'] = (df['variation_prime'] / df[col_prime_actuelle]) * 100
    
    # Catégoriser gagnants/perdants
    df['impact_categorie'] = pd.cut(
        df['variation_pct'],
        bins=[-np.inf, -10, -2, 2, 10, np.inf],
        labels=['Forte baisse (>10%)', 'Baisse (2-10%)', 'Stable (±2%)', 
                'Hausse (2-10%)', 'Forte hausse (>10%)']
    )
    
    # Résumé global
    results = {
        'global': {
            'nb_contrats': len(df),
            'prime_totale_actuelle': df[col_prime_actuelle].sum(),
            'prime_totale_nouvelle': df[col_prime_nouvelle].sum(),
            'variation_totale': df['variation_prime'].sum(),
            'variation_totale_pct': (df[col_prime_nouvelle].sum() / df[col_prime_actuelle].sum() - 1) * 100,
            'variation_moyenne_pct': df['variation_pct'].mean(),
            'variation_mediane_pct': df['variation_pct'].median()
        }
    }
    
    print("\n📊 IMPACT GLOBAL:")
    print("-" * 40)
    print(f"Nombre de contrats: {results['global']['nb_contrats']:,}")
    print(f"Prime totale actuelle: {results['global']['prime_totale_actuelle']:,.0f}€")
    print(f"Prime totale nouvelle: {results['global']['prime_totale_nouvelle']:,.0f}€")
    print(f"Variation totale: {results['global']['variation_totale']:+,.0f}€ ({results['global']['variation_totale_pct']:+.2f}%)")
    print(f"Variation moyenne par contrat: {results['global']['variation_moyenne_pct']:+.2f}%")
    
    # Répartition gagnants/perdants
    repartition = df['impact_categorie'].value_counts().sort_index()
    repartition_pct = repartition / len(df) * 100
    
    results['repartition'] = {
        'distribution': repartition.to_dict(),
        'distribution_pct': repartition_pct.to_dict()
    }
    
    print("\n📊 RÉPARTITION GAGNANTS/PERDANTS:")
    print("-" * 40)
    for cat, count in repartition.items():
        pct = repartition_pct[cat]
        print(f"{cat}: {count:,} contrats ({pct:.1f}%)")
    
    # Analyse par segment
    if segments:
        results['segments'] = {}
        
        print("\n📊 IMPACT PAR SEGMENT:")
        print("-" * 40)
        
        for segment in segments:
            if segment in df.columns:
                segment_analysis = df.groupby(segment).agg({
                    col_prime_actuelle: 'sum',
                    col_prime_nouvelle: 'sum',
                    'variation_prime': 'sum',
                    'id_contrat': 'count'
                }).rename(columns={'id_contrat': 'nb_contrats'})
                
                segment_analysis['variation_pct'] = (
                    segment_analysis['variation_prime'] / segment_analysis[col_prime_actuelle] * 100
                )
                
                results['segments'][segment] = segment_analysis.to_dict()
                
                print(f"\n{segment.upper()}:")
                print(segment_analysis[['nb_contrats', 'variation_prime', 'variation_pct']].round(2))
    
    return results, df


def simuler_impact_rentabilite(df: pd.DataFrame,
                                col_sinistres: str = 'cout_sinistre',
                                col_prime_actuelle: str = 'prime_actuelle',
                                col_prime_nouvelle: str = 'prime_nouvelle') -> Dict:
    """
    Simule l'impact sur la rentabilité (Loss Ratio).
    
    Parameters
    ----------
    df : pd.DataFrame
        Données avec sinistres et primes
    col_sinistres : str
        Colonne des sinistres
    col_prime_actuelle : str
        Prime actuelle
    col_prime_nouvelle : str
        Nouvelle prime
        
    Returns
    -------
    Dict
        Impact sur le loss ratio
    """
    print("\n📊 IMPACT SUR LA RENTABILITÉ:")
    print("-" * 40)
    
    # Calculer les loss ratios
    sinistres_total = df[col_sinistres].sum()
    prime_actuelle_total = df[col_prime_actuelle].sum()
    prime_nouvelle_total = df[col_prime_nouvelle].sum()
    
    lr_actuel = sinistres_total / prime_actuelle_total * 100
    lr_nouveau = sinistres_total / prime_nouvelle_total * 100
    
    results = {
        'sinistres_total': sinistres_total,
        'prime_actuelle_total': prime_actuelle_total,
        'prime_nouvelle_total': prime_nouvelle_total,
        'loss_ratio_actuel': lr_actuel,
        'loss_ratio_nouveau': lr_nouveau,
        'amelioration_lr': lr_actuel - lr_nouveau
    }
    
    print(f"Sinistres totaux: {sinistres_total:,.0f}€")
    print(f"Loss Ratio actuel: {lr_actuel:.1f}%")
    print(f"Loss Ratio projeté: {lr_nouveau:.1f}%")
    print(f"Amélioration: {results['amelioration_lr']:+.1f} points")
    
    return results


def exporter_analyse_impact(results: Dict,
                            df_detail: pd.DataFrame,
                            output_path: str = 'outputs/analyse_impact.xlsx') -> None:
    """
    Exporte l'analyse d'impact dans un fichier Excel.
    
    Parameters
    ----------
    results : Dict
        Résultats de l'analyse
    df_detail : pd.DataFrame
        Données détaillées
    output_path : str
        Chemin du fichier de sortie
    """
    import os
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        # Onglet Résumé
        summary = pd.DataFrame([results['global']])
        summary.to_excel(writer, sheet_name='Résumé', index=False)
        
        # Onglet Répartition
        repartition = pd.DataFrame({
            'Catégorie': list(results['repartition']['distribution'].keys()),
            'Nombre': list(results['repartition']['distribution'].values()),
            'Pourcentage': list(results['repartition']['distribution_pct'].values())
        })
        repartition.to_excel(writer, sheet_name='Répartition', index=False)
        
        # Onglet Détail (échantillon)
        df_sample = df_detail.head(10000)
        df_sample.to_excel(writer, sheet_name='Détail', index=False)
    
    print(f"\n✓ Analyse exportée: {output_path}")


def calculer_relativites_globales(model_freq, model_sev, features: List[str]) -> pd.DataFrame:
    """
    Calcule les relativités combinées (fréquence × sévérité).
    
    Parameters
    ----------
    model_freq : GLMFrequence
        Modèle de fréquence
    model_sev : GLMSeverite
        Modèle de sévérité
    features : List[str]
        Liste des features
        
    Returns
    -------
    pd.DataFrame
        Relativités globales par modalité
    """
    # Récupérer les relativités
    rel_freq = model_freq.get_relativites()
    rel_sev = model_sev.get_relativites()
    
    # Fusionner
    rel_combined = rel_freq[['relativite']].copy()
    rel_combined = rel_combined.rename(columns={'relativite': 'rel_frequence'})
    rel_combined['rel_severite'] = rel_sev['relativite']
    rel_combined['rel_prime_pure'] = rel_combined['rel_frequence'] * rel_combined['rel_severite']
    rel_combined['impact_total_pct'] = (rel_combined['rel_prime_pure'] - 1) * 100
    
    return rel_combined.round(4)


if __name__ == "__main__":
    # Test du module
    print("Test du module zonier...")
    
    from data_preparation import prepare_data
    
    # Charger les données
    df = prepare_data('data/sinistres_mrh.csv', 'data/exposition_mrh.csv')
    
    # Construire le zonier
    zonier = construire_zonier(df, n_zones=5)
    
    print("\n" + "="*50)
    print("ZONIER FINAL")
    print("="*50)
    print(zonier[['departement', 'zone', 'relativite_brute', 'relativite_lissee']].head(20))
    
    # Simuler une révision tarifaire
    print("\n" + "="*50)
    print("SIMULATION RÉVISION TARIFAIRE")
    print("="*50)
    
    # Créer des primes fictives
    df['prime_actuelle'] = df['prime_pure'].mean() * 1.3  # Prime commerciale = Prime pure × 1.3
    
    # Appliquer le zonier
    df = appliquer_zonier(df, zonier)
    
    # Nouvelle prime = Prime de base × Relativité géographique
    prime_base = df['prime_actuelle'].mean()
    df['prime_nouvelle'] = prime_base * df['relativite_geo']
    
    # Analyse d'impact
    results, df_impact = analyse_impact(
        df,
        col_prime_actuelle='prime_actuelle',
        col_prime_nouvelle='prime_nouvelle',
        segments=['zone_geo', 'type_logement']
    )
    
    # Impact rentabilité
    impact_lr = simuler_impact_rentabilite(df_impact)
    
    # Exporter
    exporter_analyse_impact(results, df_impact)
