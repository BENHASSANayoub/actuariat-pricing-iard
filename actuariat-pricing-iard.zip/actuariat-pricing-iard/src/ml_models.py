"""
Module Machine Learning pour l'actuariat pricing
=================================================

Implémentation des modèles ML pour benchmark :
- Random Forest
- XGBoost
- Comparaison avec GLM

Auteur: Ayoub BENHASSAN
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import LabelEncoder
import xgboost as xgb
from typing import List, Dict, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')


class RandomForestModel:
    """
    Modèle Random Forest pour la prédiction de prime pure.
    
    Random Forest = Ensemble d'arbres de décision :
    1. Bagging : échantillons bootstrap
    2. Décorrélation : sous-ensemble de variables à chaque split
    3. Agrégation : moyenne des prédictions
    
    Avantages :
    - Capture les non-linéarités automatiquement
    - Robuste aux outliers
    - Peu de risque de sur-apprentissage
    
    Inconvénients :
    - Moins interprétable que GLM
    - Difficile à valider réglementairement
    """
    
    def __init__(self, **kwargs):
        """
        Initialise le modèle Random Forest.
        
        Parameters
        ----------
        **kwargs
            Paramètres passés à RandomForestRegressor
        """
        default_params = {
            'n_estimators': 200,
            'max_depth': 15,
            'min_samples_split': 10,
            'min_samples_leaf': 5,
            'max_features': 'sqrt',
            'random_state': 42,
            'n_jobs': -1
        }
        default_params.update(kwargs)
        
        self.model = RandomForestRegressor(**default_params)
        self.feature_names = None
        self.label_encoders = {}
        
    def _prepare_features(self, df: pd.DataFrame, 
                          features: List[str],
                          fit: bool = True) -> pd.DataFrame:
        """
        Prépare les features (encodage des catégorielles).
        
        Parameters
        ----------
        df : pd.DataFrame
            Données source
        features : List[str]
            Liste des features
        fit : bool
            True pour fit les encoders, False pour transform
            
        Returns
        -------
        pd.DataFrame
            Features encodées
        """
        X = df[features].copy()
        
        # Identifier les colonnes catégorielles
        cat_cols = X.select_dtypes(include=['object', 'category']).columns.tolist()
        
        for col in cat_cols:
            if fit:
                le = LabelEncoder()
                X[col] = le.fit_transform(X[col].astype(str))
                self.label_encoders[col] = le
            else:
                if col in self.label_encoders:
                    # Gérer les catégories inconnues
                    le = self.label_encoders[col]
                    X[col] = X[col].astype(str).apply(
                        lambda x: le.transform([x])[0] if x in le.classes_ else -1
                    )
        
        return X
    
    def fit(self, df: pd.DataFrame,
            features: List[str],
            target: str = 'prime_pure') -> 'RandomForestModel':
        """
        Entraîne le modèle Random Forest.
        
        Parameters
        ----------
        df : pd.DataFrame
            Données d'entraînement
        features : List[str]
            Liste des features
        target : str
            Variable cible
            
        Returns
        -------
        self
        """
        self.feature_names = features
        
        # Préparer les features
        X = self._prepare_features(df, features, fit=True)
        y = df[target]
        
        print(f"📊 Entraînement Random Forest")
        print(f"   Features: {features}")
        print(f"   Observations: {len(X):,}")
        
        # Entraîner le modèle
        self.model.fit(X, y)
        
        print(f"✓ Modèle entraîné")
        
        return self
    
    def predict(self, df: pd.DataFrame) -> np.ndarray:
        """
        Prédit avec le modèle.
        
        Parameters
        ----------
        df : pd.DataFrame
            Données pour prédiction
            
        Returns
        -------
        np.ndarray
            Prédictions
        """
        X = self._prepare_features(df, self.feature_names, fit=False)
        return self.model.predict(X)
    
    def get_feature_importance(self) -> pd.DataFrame:
        """
        Retourne l'importance des variables.
        
        Returns
        -------
        pd.DataFrame
            Importance des variables triées
        """
        importance = pd.DataFrame({
            'feature': self.feature_names,
            'importance': self.model.feature_importances_
        }).sort_values('importance', ascending=False)
        
        importance['importance_pct'] = importance['importance'] / importance['importance'].sum() * 100
        
        return importance.reset_index(drop=True)
    
    def cross_validate(self, df: pd.DataFrame,
                       features: List[str],
                       target: str = 'prime_pure',
                       cv: int = 5) -> Dict:
        """
        Validation croisée du modèle.
        
        Parameters
        ----------
        df : pd.DataFrame
            Données complètes
        features : List[str]
            Features
        target : str
            Variable cible
        cv : int
            Nombre de folds
            
        Returns
        -------
        Dict
            Métriques de cross-validation
        """
        X = self._prepare_features(df, features, fit=True)
        y = df[target]
        
        # Cross-validation
        scores_rmse = cross_val_score(self.model, X, y, 
                                       cv=cv, 
                                       scoring='neg_root_mean_squared_error')
        scores_r2 = cross_val_score(self.model, X, y, 
                                     cv=cv, 
                                     scoring='r2')
        
        results = {
            'cv_folds': cv,
            'rmse_mean': -scores_rmse.mean(),
            'rmse_std': scores_rmse.std(),
            'r2_mean': scores_r2.mean(),
            'r2_std': scores_r2.std()
        }
        
        print(f"\n📊 CROSS-VALIDATION ({cv} folds)")
        print(f"   RMSE: {results['rmse_mean']:.2f} (± {results['rmse_std']:.2f})")
        print(f"   R²: {results['r2_mean']:.3f} (± {results['r2_std']:.3f})")
        
        return results
    
    def tune_hyperparameters(self, df: pd.DataFrame,
                             features: List[str],
                             target: str = 'prime_pure',
                             param_grid: Dict = None) -> Dict:
        """
        Optimise les hyperparamètres par Grid Search.
        
        Parameters
        ----------
        df : pd.DataFrame
            Données
        features : List[str]
            Features
        target : str
            Variable cible
        param_grid : Dict
            Grille de paramètres (optionnel)
            
        Returns
        -------
        Dict
            Meilleurs paramètres
        """
        if param_grid is None:
            param_grid = {
                'n_estimators': [100, 200],
                'max_depth': [10, 15, 20],
                'min_samples_leaf': [3, 5, 10]
            }
        
        X = self._prepare_features(df, features, fit=True)
        y = df[target]
        
        print(f"📊 Grid Search...")
        
        grid_search = GridSearchCV(
            RandomForestRegressor(random_state=42, n_jobs=-1),
            param_grid,
            cv=3,
            scoring='neg_root_mean_squared_error',
            verbose=1
        )
        grid_search.fit(X, y)
        
        print(f"\n✓ Meilleurs paramètres: {grid_search.best_params_}")
        print(f"   Meilleur RMSE: {-grid_search.best_score_:.2f}")
        
        # Mettre à jour le modèle avec les meilleurs paramètres
        self.model = grid_search.best_estimator_
        
        return grid_search.best_params_


class XGBoostModel:
    """
    Modèle XGBoost pour la prédiction de prime pure.
    
    XGBoost = Gradient Boosting optimisé :
    1. Construction séquentielle des arbres
    2. Chaque arbre corrige les erreurs du précédent
    3. Régularisation L1/L2 intégrée
    
    Avantages :
    - Souvent meilleures performances que RF
    - Early stopping pour éviter l'overfitting
    - Gère les valeurs manquantes
    
    Inconvénients :
    - Plus de paramètres à tuner
    - Plus sensible au sur-apprentissage
    """
    
    def __init__(self, **kwargs):
        """
        Initialise le modèle XGBoost.
        
        Parameters
        ----------
        **kwargs
            Paramètres XGBoost
        """
        default_params = {
            'objective': 'reg:squarederror',
            'max_depth': 6,
            'learning_rate': 0.1,
            'subsample': 0.8,
            'colsample_bytree': 0.8,
            'reg_lambda': 1,
            'seed': 42
        }
        default_params.update(kwargs)
        
        self.params = default_params
        self.model = None
        self.feature_names = None
        self.label_encoders = {}
        
    def _prepare_features(self, df: pd.DataFrame,
                          features: List[str],
                          fit: bool = True) -> pd.DataFrame:
        """Prépare les features."""
        X = df[features].copy()
        
        cat_cols = X.select_dtypes(include=['object', 'category']).columns.tolist()
        
        for col in cat_cols:
            if fit:
                le = LabelEncoder()
                X[col] = le.fit_transform(X[col].astype(str))
                self.label_encoders[col] = le
            else:
                if col in self.label_encoders:
                    le = self.label_encoders[col]
                    X[col] = X[col].astype(str).apply(
                        lambda x: le.transform([x])[0] if x in le.classes_ else -1
                    )
        
        return X
    
    def fit(self, df: pd.DataFrame,
            features: List[str],
            target: str = 'prime_pure',
            validation_split: float = 0.2,
            early_stopping_rounds: int = 50,
            num_boost_round: int = 500,
            verbose: bool = True) -> 'XGBoostModel':
        """
        Entraîne le modèle XGBoost avec early stopping.
        
        Parameters
        ----------
        df : pd.DataFrame
            Données d'entraînement
        features : List[str]
            Features
        target : str
            Variable cible
        validation_split : float
            Proportion pour validation
        early_stopping_rounds : int
            Rounds sans amélioration avant arrêt
        num_boost_round : int
            Nombre maximum d'itérations
        verbose : bool
            Afficher les logs
            
        Returns
        -------
        self
        """
        self.feature_names = features
        
        # Préparer les features
        X = self._prepare_features(df, features, fit=True)
        y = df[target]
        
        # Split train/validation
        X_train, X_val, y_train, y_val = train_test_split(
            X, y, test_size=validation_split, random_state=42
        )
        
        # Créer les DMatrix
        dtrain = xgb.DMatrix(X_train, label=y_train, feature_names=features)
        dval = xgb.DMatrix(X_val, label=y_val, feature_names=features)
        
        print(f"📊 Entraînement XGBoost")
        print(f"   Features: {features}")
        print(f"   Train: {len(X_train):,}, Validation: {len(X_val):,}")
        
        # Entraîner avec early stopping
        evals = [(dtrain, 'train'), (dval, 'validation')]
        
        self.model = xgb.train(
            self.params,
            dtrain,
            num_boost_round=num_boost_round,
            evals=evals,
            early_stopping_rounds=early_stopping_rounds,
            verbose_eval=50 if verbose else False
        )
        
        print(f"\n✓ Modèle entraîné")
        print(f"   Meilleures itérations: {self.model.best_iteration}")
        
        return self
    
    def predict(self, df: pd.DataFrame) -> np.ndarray:
        """Prédit avec le modèle."""
        X = self._prepare_features(df, self.feature_names, fit=False)
        dmatrix = xgb.DMatrix(X, feature_names=self.feature_names)
        return self.model.predict(dmatrix)
    
    def get_feature_importance(self, importance_type: str = 'gain') -> pd.DataFrame:
        """
        Retourne l'importance des variables.
        
        Parameters
        ----------
        importance_type : str
            'gain', 'weight', 'cover'
            
        Returns
        -------
        pd.DataFrame
            Importance des variables
        """
        importance = self.model.get_score(importance_type=importance_type)
        
        importance_df = pd.DataFrame({
            'feature': list(importance.keys()),
            'importance': list(importance.values())
        }).sort_values('importance', ascending=False)
        
        importance_df['importance_pct'] = importance_df['importance'] / importance_df['importance'].sum() * 100
        
        return importance_df.reset_index(drop=True)


def evaluer_modele(y_true: np.ndarray, 
                   y_pred: np.ndarray,
                   model_name: str = "Modèle") -> Dict:
    """
    Évalue les performances d'un modèle.
    
    Parameters
    ----------
    y_true : np.ndarray
        Valeurs réelles
    y_pred : np.ndarray
        Valeurs prédites
    model_name : str
        Nom du modèle
        
    Returns
    -------
    Dict
        Métriques d'évaluation
    """
    metrics = {
        'model': model_name,
        'rmse': np.sqrt(mean_squared_error(y_true, y_pred)),
        'mae': mean_absolute_error(y_true, y_pred),
        'r2': r2_score(y_true, y_pred),
        'mape': np.mean(np.abs((y_true - y_pred) / (y_true + 1e-8))) * 100
    }
    
    print(f"\n📊 ÉVALUATION - {model_name}")
    print(f"   RMSE: {metrics['rmse']:.2f}")
    print(f"   MAE: {metrics['mae']:.2f}")
    print(f"   R²: {metrics['r2']:.4f}")
    print(f"   MAPE: {metrics['mape']:.1f}%")
    
    return metrics


def comparer_modeles_ml(df_train: pd.DataFrame,
                        df_test: pd.DataFrame,
                        features: List[str],
                        target: str = 'prime_pure') -> pd.DataFrame:
    """
    Compare les modèles ML entre eux et avec GLM.
    
    Parameters
    ----------
    df_train : pd.DataFrame
        Données d'entraînement
    df_test : pd.DataFrame
        Données de test
    features : List[str]
        Features
    target : str
        Variable cible
        
    Returns
    -------
    pd.DataFrame
        Comparaison des modèles
    """
    results = []
    
    # 1. Random Forest
    print("\n" + "="*50)
    print("RANDOM FOREST")
    print("="*50)
    
    rf = RandomForestModel()
    rf.fit(df_train, features, target)
    rf_pred = rf.predict(df_test)
    rf_metrics = evaluer_modele(df_test[target], rf_pred, "Random Forest")
    results.append(rf_metrics)
    
    # 2. XGBoost
    print("\n" + "="*50)
    print("XGBOOST")
    print("="*50)
    
    xgb_model = XGBoostModel()
    xgb_model.fit(df_train, features, target, verbose=False)
    xgb_pred = xgb_model.predict(df_test)
    xgb_metrics = evaluer_modele(df_test[target], xgb_pred, "XGBoost")
    results.append(xgb_metrics)
    
    # Tableau comparatif
    comparison = pd.DataFrame(results)
    comparison = comparison.sort_values('rmse')
    
    print("\n" + "="*50)
    print("COMPARAISON DES MODÈLES")
    print("="*50)
    print(comparison.to_string(index=False))
    
    return comparison, rf, xgb_model


if __name__ == "__main__":
    # Test du module
    print("Test du module ml_models...")
    
    from data_preparation import prepare_data, split_train_test
    
    # Charger les données
    df = prepare_data('data/sinistres_mrh.csv', 'data/exposition_mrh.csv')
    
    # Split train/test
    df_train, df_test = split_train_test(df, test_size=0.2)
    
    # Features
    features = ['type_logement', 'zone_geo', 'age_groupe', 'surface_groupe', 'etage']
    
    # Comparer les modèles
    comparison, rf, xgb_model = comparer_modeles_ml(df_train, df_test, features)
    
    # Importance des variables
    print("\n" + "="*50)
    print("IMPORTANCE DES VARIABLES - Random Forest")
    print("="*50)
    print(rf.get_feature_importance())
    
    print("\n" + "="*50)
    print("IMPORTANCE DES VARIABLES - XGBoost")
    print("="*50)
    print(xgb_model.get_feature_importance())
